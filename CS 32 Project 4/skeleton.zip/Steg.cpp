#include "provided.h"
#include <string>
using namespace std;

bool Steg::hide(const string& hostIn, const string& msg, string& hostOut) 
{
	return false;  // This compiles, but may not be correct
}

bool Steg::reveal(const string& hostIn, string& msg) 
{
	return false;  // This compiles, but may not be correct
}
